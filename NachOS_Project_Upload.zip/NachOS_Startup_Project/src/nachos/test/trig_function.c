/*
 *  If a number between 0 and 50 is entered, this
 function will tell you if its prime.
 */

#include "stdlib.h"

#define BUFFERSIZE	16

#define MAXARGSIZE	16
#define MAXARGS		16

int isPrime(int mightBePrime){
        if (mightBePrime <= 50 && mightBePrime > 0){
                if (mightBePrime == 2 ||
                mightBePrime == 3 ||
                mightBePrime == 5 ||
                mightBePrime == 7 ||
                mightBePrime == 11 ||
                mightBePrime == 13 ||
                mightBePrime == 17 ||
                mightBePrime == 19 ||
                mightBePrime == 23 ||
                mightBePrime == 37 ||
                mightBePrime == 41 ||
                mightBePrime == 43 ||
                mightBePrime == 47)
                {
                return mightBePrime; // is prime
                }
                else{
                    return -2;  //in range but not prime
                } 
        }
        else{
                return -1; // not in range
        }

}

int main(int argc, char *argv[]){
        char length1[BUFFERSIZE];
        printf("%s", "Your number: ");
        readline(length1, BUFFERSIZE);

        int l1 = atoi(length1);

        int answer = isPrime(l1);

        if (answer == -1){ // not in range
                printf("Number outside of Established Parameters");
                return -1;
        }
        if (answer == -2){ // not prime
                printf("Number is not prime");
                return -1;
        }
        else{ //prime
                printf("%d is prime!\n", answer);
                return answer;        
        }
        
}
