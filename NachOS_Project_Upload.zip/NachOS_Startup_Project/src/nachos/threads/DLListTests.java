package nachos.threads;

import org.junit.*;
import org.junit.rules.Timeout;
import static org.junit.Assert.*;

public class DLListTests {

    @Rule // a test will fail if it takes longer than 10 seconds / 1/10 of a second to run
    public Timeout timeout = Timeout.millis(100);

    @Test // tests prepend
    public void prependTest1(){
        DLList l = new DLList();
        l.prepend("A");
        String actual = l.toString() + " Size: " +  l.size();
        String expected = "([0,A]) Size: 1";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void prependTest2(){
        DLList l = new DLList();
        l.prepend("A");
        l.prepend("B");
        String actual = l.toString() + " Size: " + l.size();;
        String expected = "([-1,B] [0,A]) Size: 2";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void prependTest3(){
        DLList l = new DLList();
        l.prepend("C");
        l.prepend("B");
        l.prepend("A");
        String actual = l.toString() + " Size: " + l.size();;
        String expected = "([-2,A] [-1,B] [0,C]) Size: 3";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void removeHead1(){
        DLList l = new DLList();
        Object actual = l.removeHead();
        String expected = null;
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void removeHead2(){
        DLList l = new DLList();
        l.prepend("testString");
        Object actual = l.removeHead();
        String expected = "testString";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void removeHead3(){
        DLList l = new DLList();
        l.prepend("C");
        l.removeHead();
        String actual = l.toString() + " Size: " + l.size();
        String expected = "() Size: 0";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void removeHead4(){
        DLList l = new DLList();
        l.prepend("C");
        l.prepend("B");
        l.prepend("A");
        l.removeHead();
        l.removeHead();
        l.removeHead();
        String actual = l.toString() + " Size: " + l.size();
        String expected = "() Size: 0";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void removeHead5(){
        DLList l = new DLList();
        l.prepend("D");
        l.prepend("C");
        l.prepend("B");
        l.prepend("A");
        l.removeHead();
        String actual = l.toString() + " Size: " + l.size();
        String expected = "([-2,B] [-1,C] [0,D]) Size: 3";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void removeHead6(){
        DLList l = new DLList();
        l.insert("A", -3);
        l.insert("B", -2);
        l.insert("C", -1);
        l.insert("D", 0);
        l.removeHead();
        String actual = l.reverseToString();
        String expected = "([0,D] [-1,C] [-2,B])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void isEmptyTest1(){
        DLList l = new DLList();
        boolean actual = l.isEmpty();
        boolean expected = true;
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void isEmptyTest2(){
        DLList l = new DLList();
        l.prepend(" C ");
        l.removeHead();
        boolean actual = l.isEmpty();
        boolean expected = true;
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void isEmptyTest3(){
        DLList l = new DLList();
        l.prepend(" B ");
        l.prepend(" A ");
        l.removeHead();
        boolean actual = l.isEmpty();
        boolean expected = false;
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void insertTest1(){
        DLList l = new DLList();
        l.insert("A", 0);
        String actual = l.toString();
        String expected = "([0,A])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void insertTest2(){
        DLList l = new DLList();
        l.insert("C", 0);
        l.insert("B", -1);
        l.insert("A", -2);
        String actual = l.toString();
        String expected = "([-2,A] [-1,B] [0,C])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void insertTest3(){
        DLList l = new DLList();
        l.insert("A", 0);
        l.insert("B", 1);
        l.insert("C", 2);
        String actual = l.toString();
        String expected = "([0,A] [1,B] [2,C])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void insertTest4(){
        DLList l = new DLList();
        l.insert("A", 0);
        l.insert("E", 4);
        l.insert("C", 2);
        l.insert("D", 3);
        l.insert("B", 1);
        String actual = l.toString();
        String expected = "([0,A] [1,B] [2,C] [3,D] [4,E])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void insertTest5(){
        DLList l = new DLList();
        l.insert("B", 3);
        l.insert("A", 3);
        String actual = l.toString();
        String expected = "([3,A] [3,B])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void insertTest6(){
        DLList l = new DLList();
        l.insert("A", 0);
        l.insert("G", 4);
        l.insert("C", 2);
        l.insert("F", 3);
        l.insert("B", 1);
        l.insert("E", 3);
        l.insert("D", 3);
        String actual = l.toString();
        String expected = "([0,A] [1,B] [2,C] [3,D] [3,E] [3,F] [4,G])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void revToStringTest1(){
        DLList l = new DLList();
        l.insert("A", 0);
        l.insert("G", 4);
        l.insert("C", 2);
        l.insert("F", 3);
        l.insert("B", 1);
        l.insert("E", 3);
        l.insert("D", 3);
        String actual = l.reverseToString();
        String expected = "([4,G] [3,F] [3,E] [3,D] [2,C] [1,B] [0,A])";
        assertEquals(expected, actual);
    }

    @Test // tests prepend
    public void revToStringTest2(){
        DLList l = new DLList();
        l.insert("A", 0);
        l.insert("G", 4);
        l.insert("C", 2);
        l.insert("F", 3);
        l.insert("B", 1);
        l.insert("E", 3);
        l.insert("D", 3);
        l.removeHead();
        l.removeHead();
        l.prepend("#1");
        String actual = l.reverseToString();
        String expected = "([4,G] [3,F] [3,E] [3,D] [2,C] [1,#1])";
        assertEquals(expected, actual);
    }

}