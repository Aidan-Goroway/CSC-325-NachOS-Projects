package nachos.threads;  // don't change this. Gradescope needs it.

public class DLList
{
    private DLLElement first;  // pointer to first node
    private DLLElement last;   // pointer to last node
    private int size;          // number of nodes in list
    private Lock lock;
    private Condition2 DLListNotEmpty;

    /**
     * Creates an empty sorted doubly-linked list.
     */ 
    public DLList() {
        size = 0;
        first = null;
        last = null;
        lock = new Lock();
        DLListNotEmpty = new Condition2(lock);
    }

    /**
     * Add item to the head of the list, setting the key for the new
     * head element to min_key - 1, where min_key is the smallest key
     * in the list (which should be located in the first node).
     * If no nodes exist yet, the key will be 0.
     */
    public void prepend(Object item) {
        lock.acquire();
        if (size() == 0){ // newNode is first node in DDList
            DLLElement newnode = new DLLElement(item, 0);
            // KThread.yieldIfShould(4); // invalid list test: true on 1st pass
            first = newnode;              // false on 2nd pass
            // KThread.yieldIfShould(5); // invalid list test: true on 1st pass,
            last = newnode;               // false on 2nd pass
            // KThread.yieldIfShould(6); // invalid list test: true on 1st pass,
        }                                 // TRUE on 2nd pass
        else{ // newNode is just a new head, but not the first node in the list
            KThread.yieldIfShould(0); //Fatal Error test: true on 1st (only) pass
            DLLElement newnode = new DLLElement(item, first.key - 1);
            first.prev = newnode;
            newnode.next = first;
            first = newnode;
            // KThread.yieldIfShould(1); // Fatal error test: true on 1st (only pass
            first.prev = null;
        }
        size++;
        DLListNotEmpty.wake();
        lock.release();
    }

    /**
     * Removes the head of the list and returns the data item stored in
     * it.  Returns null if no nodes exist.
     *
     * @return the data stored at the head of the list or null if list empty
     */
    public Object removeHead() {
        lock.acquire();
        while (size == 0){
            DLListNotEmpty.sleep();
        }
        Object savedData = first.data;
        DLLElement savedPlace = first.next;
        // KThread.yieldIfShould(2); //fatal error test: true on 1st (only) pass
        first = null;
        // KThread.yieldIfShould(3); //fatal error test: true on 1st (only) pass
        first = savedPlace;
        size--;
        if (size() > 0){
            first.prev = null;
        }
        lock.release();
        return savedData;
    }

    /**
     * Tests whether the list is empty.
     *
     * @return true iff the list is empty.
     */
    public boolean isEmpty() {
        lock.acquire();
        boolean isEmpty = isEmpty(true);
        lock.release();
        return isEmpty;
    }

    /**
     * The private method that isEmpty() calls. In cases where methods of DLList call isEmpty
     * and the method is already locked, locking again will cause a crash. This lock-less 
     * private version of isEmpty solves that problem.
     * @param fillerParam Exists to differentiate the two isEmpty methods.
     * Can be true or false, with no difference.
     * @return true iff the list is empty.
     */
    private boolean isEmpty(boolean fillerParam){
        boolean isEmpty;
        if (size() == 0){
            isEmpty = true;
        }
        else{
            isEmpty = false;
        }
        return isEmpty;
    }

    /**
     * returns number of items in list
     * @return returns the size of the DLList
     */
    public int size(){
        return size;
    }


    /**
     * Inserts item into the list in sorted order according to sortKey.
     */
    public void insert(Object item, Integer sortKey) {
        lock.acquire();
        DLLElement newnode = new DLLElement(item, sortKey);
        if (size() == 0){ // newNode is the very first node in the list
            first = newnode;
            last = newnode;
        }
        else{
            if (sortKey < first.key){ // newNode is new first
                first.prev = newnode;
                newnode.next = first;
                first = newnode;
                first.prev = null;
            }
            else if(sortKey > last.key){ // newNode is new last
                last.next = newnode;
                newnode.prev = last;
                last = newnode;
                last.next = null;
            }
            else{ // newNode is somewhere in the middle
                DLLElement curent = first; // a way of keeping track of nodes
                boolean loopVar = true;
                if (curent.next == null){ // sortkey is identical to another. 
                    // Always places node previously to the one with an identical key.
                    first.prev = newnode;
                    newnode.next = first;
                    first = newnode;
                    first.prev = null;
                    loopVar = false;
                }
                while (curent.next != null && loopVar){
                    if (curent.key < sortKey && curent.next.key >= sortKey){
                        DLLElement postCurent = curent.next;
                        curent.next = newnode;
                        newnode.prev = curent;
                        postCurent.prev = newnode;
                        newnode.next = postCurent;
                        loopVar = false;
                    }
                    else{
                        curent = curent.next;
                    }
                }
            }
        }
        DLListNotEmpty.wake();
        size++;
        lock.release();
    }


    /**
     * returns list as a printable string. A single space should separate each list item,
     * and the entire list should be enclosed in parentheses. Empty list should return "()"
     * @return list elements in order
     */
    public String toString() {
        lock.acquire();
        if (isEmpty(true)){
            lock.release();
            return "()";
        }
        else{
            String toReturn = "(";
            DLLElement curent = first; 
            while(curent != null){
                toReturn = toReturn + "[" + curent.key + "," + curent.data + "]";
                curent = curent.next;
                if (curent != null){
                    toReturn = toReturn + " ";
                }
            }
            toReturn = toReturn + ")";
            lock.release();
            return toReturn;
        }
    }

    /**
     * returns list as a printable string, from the last node to the first.
     * String should be formatted just like in toString.
     * @return list elements in backwards order
     */
    public String reverseToString(){
        lock.acquire();
        if (isEmpty(true)){
            lock.release();
            return "()";
        }
        else{
            String toReturn = "(";
            DLLElement curent = last; 
            while(curent != null){
                toReturn = toReturn + "[" + curent.key + "," + curent.data + "]";
                curent = curent.prev;
                if (curent != null){
                    toReturn = toReturn + " ";
                }
            }
            toReturn = toReturn + ")";
            lock.release();
            return toReturn;
        }
    }

    /**
     *  inner class for the node
     */
    private class DLLElement
    {
        private DLLElement next; 
        private DLLElement prev;
        private int key;
        private Object data;

        /**
         * Node constructor
         * @param item data item to store
         * @param sortKey unique integer ID
         */
        public DLLElement(Object item, int sortKey)
        {
        	key = sortKey;
        	data = item;
        	next = null;
        	prev = null;
        }

        /**
         * returns node contents as a printable string
         * @return string of form [<key>,<data>] such as [3,"ham"]
         */
        public String toString(){
            return "[" + key + "," + data + "]";
        }
    }
}
