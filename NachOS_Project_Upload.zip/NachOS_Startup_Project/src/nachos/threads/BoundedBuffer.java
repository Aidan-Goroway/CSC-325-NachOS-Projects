package nachos.threads;

import nachos.machine.*;

public class BoundedBuffer{

    private char buffer[];
    private Lock lock;
    private Condition2 emptySlot;
    private Condition2 fullSlot;

    int nextIN;
    int nextOUT;
    int count;

    /**
     * non-default constructor with a fixed size
     * @param maxsize maximum size the buffer can be. This size is fixed.
     */
    public BoundedBuffer(int maxsize){
        buffer = new char[maxsize];
        nextIN = 0;
        nextOUT = 0;
        count = 0;
        lock = new Lock();
        emptySlot = new Condition2(lock);
        fullSlot = new Condition2(lock);
    }

    /*
    * Read a character from the buffer, blocking until there is a char
    * in the buffer to satisfy the request. Return the char read.
    */
    public char read(){ //removes from buffer
        lock.acquire();
        if (count == 0){
            fullSlot.sleep();
        }
        char readChar = buffer[nextOUT];
        nextOUT = (nextOUT + 1) % buffer.length;
        count --;
        emptySlot.wake();
        lock.release();
        return readChar;
    }

    /** Write the given character c into the buffer, blocking until
    * enough space is available to satisfy the request.
    * @param c character written into the buffer.
    */
    public void write(char c){ //adds to buffer
        lock.acquire();
        int n = buffer.length;
        if (count == n){
            emptySlot.sleep();
        }
        buffer[nextIN] = c;
        nextIN = (nextIN + 1) % n;
        count++;
        fullSlot.wake();
        lock.release();
    }

    /**
    * Prints the contents of the buffer. 
    * FOR DEBBUGGING ONLY.
    */
    public void print(){
        String toPrint = "( ";
        for (int i = 0; i < buffer.length; i++){
            if (buffer[i] != '\0'){ // null character /0 is needed for char == null
                toPrint += buffer[i] + " ";
            }
        }
        toPrint += ")";
        System.out.println(toPrint);
    }

}