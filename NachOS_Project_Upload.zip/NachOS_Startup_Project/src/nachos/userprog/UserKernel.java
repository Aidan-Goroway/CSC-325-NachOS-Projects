package nachos.userprog;

import nachos.machine.*;
import nachos.threads.*;
import nachos.userprog.*;

/**
 * A kernel that can support multiple user processes.
 */
public class UserKernel extends ThreadedKernel {
    /**
     * Allocate a new user kernel.
     */
    public UserKernel() {
	super();
    }

    /**
     * Initialize this kernel. Creates a synchronized console and sets the
     * processor's exception handler.
     */
    public void initialize(String[] args) {
	super.initialize(args);

	console = new SynchConsole(Machine.console());

    freeList = new DLList();
    int numPhysPages = Machine.processor().getNumPhysPages();
    for (int frameNumber = 0; frameNumber < numPhysPages; frameNumber++){
        freeList.insert(frameNumber, frameNumber);
        // List contains numPhysPages number of frames
    }
	
	Machine.processor().setExceptionHandler(new Runnable() {
		public void run() { exceptionHandler(); }
	    });
    }

    /**
     * Test the console device. Keep commented out.
     */
    /* 	
    public void selfTest() {
	super.selfTest();

	System.out.println("Testing the console device. Typed characters");
	System.out.println("will be echoed until q is typed.");

	char c;

	do {
	    c = (char) console.readByte(true);
	    console.writeByte(c);
	}
	while (c != 'q');

	System.out.println("");
    }
    */

    /**
    * Returns a list of <requested> free frame numbers that can be used
    * for a process.
    *
    * @param requested number of free frames requested
    * @return array of frame numbers that the process can use or null
    * if request cannot be fulfilled
    */
    public static int[] allocatePages(int requested){
        if (freeList.size() > requested){
            int[] allocatedPages = new int[requested];
            // for (int allocate = 0; allocate < requested; allocate++){
            for (int allocate = requested - 1; allocate >= 0; allocate--){
                // System.out.println(allocate);
                // System.out.println(requested);
                // System.out.println(freeList.size());
                allocatedPages[allocate] = (int) freeList.removeHead();
            }
            return allocatedPages;
        }
        else { // request cannot be fulfilled
            return null;
        }
    }

    /**
    * Puts frameNumber back in the free frames list.
    */
    public static void releasePage(int frameNumber){
        freeList.insert(frameNumber, freeList.size());
    }

    /**
     * Returns the current process.
     *
     * @return	the current process, or <tt>null</tt> if no process is current.
     */
    public static UserProcess currentProcess() {
	if (!(KThread.currentThread() instanceof UThread))
	    return null;
	
	return ((UThread) KThread.currentThread()).process;
    }

    /**
     * The exception handler. This handler is called by the processor whenever
     * a user instruction causes a processor exception.
     *
     * <p>
     * When the exception handler is invoked, interrupts are enabled, and the
     * processor's cause register contains an integer identifying the cause of
     * the exception (see the <tt>exceptionZZZ</tt> constants in the
     * <tt>Processor</tt> class). If the exception involves a bad virtual
     * address (e.g. page fault, TLB miss, read-only, bus error, or address
     * error), the processor's BadVAddr register identifies the virtual address
     * that caused the exception.
     */
    public void exceptionHandler() {
	Lib.assertTrue(KThread.currentThread() instanceof UThread);

	UserProcess process = ((UThread) KThread.currentThread()).process;
	int cause = Machine.processor().readRegister(Processor.regCause);
	process.handleException(cause);
    }

    /**
     * Start running user programs, by creating a process and running a shell
     * program in it. The name of the shell program it must run is returned by
     * <tt>Machine.getShellProgramName()</tt>.
     *
     * @see	nachos.machine.Machine#getShellProgramName
     */
    public void run() {
	super.run();

	UserProcess process = UserProcess.newUserProcess();
	
	String shellProgram = Machine.getShellProgramName();	
	Lib.assertTrue(process.execute(shellProgram, new String[] { }));

	KThread.currentThread().finish();
    }

    /**
     * Terminate this kernel. Never returns.
     */
    public void terminate() {
	super.terminate();
    }

    /** Globally accessible reference to the synchronized console. */
    public static SynchConsole console;

    /** List of frames, thread-safe and concurrently accessable by 
    * every instance if UserProcess.
    */
    public static DLList freeList;

    // dummy variables to make javac smarter
    private static Coff dummy1 = null;
}
